# project-a-0.1

Godot 模块化角色与本地随机 NPC 原型。

## 已实现

- GandalfHardcore 全套皮肤、头发、服装、鞋和武器外观目录
- 10×7 精灵表的统一帧驱动
- 只使用 idle（第 0 行 5 帧）和 run（第 2 行 8 帧）
- Player 与 NPC 场景
- WASD / 方向键输入
- R 键随机更换玩家外观
- 玩家与世界碰撞
- NPC 导航、语义锚点和稳定随机外观
- 同一 `npc_id + world_seed` 会生成相同外观

主测试场景：`res://scenes/debug/integration_test.tscn`

