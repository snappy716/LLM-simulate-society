# Project A 0.2 世界模拟接入说明

## 运行时操作

- `Q`：打开或关闭完整 NPC 列表。
- 在列表中选择 NPC：查看状态、愿望、四时段计划、近期记忆和 idle 第一帧外观。
- `到达这个人的位置`：将玩家传送到该 NPC 附近。
- `下一时间段`：依次推进 `morning -> afternoon -> evening -> late_night -> 次日 morning`。
- `Esc`：打开或关闭接口配置面板。

NPC 会根据当前时段计划中的 `scene_id`，确定性地出现在对应地图区域。当前版本只改变其出现位置，不执行地图动作。

## 接口配置面板

1. 按 `Esc` 打开面板。
2. 从左侧选择已有配置，或点击 `新增` 创建配置。
3. 选择接口类型并填写地址、模型与 API Key。
4. 点击 `保存并应用`。

目前支持：

- `规则模式（离线）`：不联网，使用本地规则规划。
- `DeepSeek`：使用 DeepSeek API。
- `DeepSeek兼容接口`：连接采用相同请求格式的服务。
- `Ollama（本地）`：连接本机 Ollama 服务。

保存并应用只会切换当前规划接口，不会立即调用外部服务。接口会在下一次日终规划时使用。

配置保存在 `user://llm_interfaces.cfg`，不会写入项目目录或模拟快照。API Key 在输入框中会被遮挡，但配置文件本身没有加密；不要在共享电脑上保存正式密钥。

## 本地模拟桥

Godot 启动以下本地进程：

```text
tools/simulation/godot_simulation_server.py
```

该进程在内存中保持 Python `World` 对象，并只监听 `127.0.0.1:8765`。默认使用离线规则规划，不会因为打开项目而访问外部 LLM。

## 地图区域

21 个公共模拟场景与地图区域的确定性映射位于：

```text
data/simulation/scene_regions.json
```

私人场景 `home_001` 至 `home_200` 暂时映射到 `home_quarter`。隐藏地点和不可进入的室内地点使用其外部入口区域。
