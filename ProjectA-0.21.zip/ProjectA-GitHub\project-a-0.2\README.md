# project-a-0.2

Godot 等距城市、模块化角色与 Python 世界模拟接入原型。

## 已实现

- GandalfHardcore 全套皮肤、头发、服装、鞋和武器外观目录
- 10×7 精灵表的统一帧驱动
- 只使用 idle（第 0 行 5 帧）和 run（第 2 行 8 帧）
- Player 与 NPC 场景
- WASD / 方向键输入
- R 键随机更换玩家外观
- 玩家与世界碰撞
- NPC 导航、语义锚点和稳定随机外观
- 同一 `npc_id + world_seed` 会生成相同外观
- 200 名模拟 NPC 与四时段世界推进
- Q 键人物列表、详情查看与快速定位
- M 键地图与内置地图矫正模式
- Esc 键配置离线规则、DeepSeek、兼容接口或 Ollama
- 靠近 NPC 后按 F 进行文字对话
- 对话使用 NPC 的状态、记忆、知识和计划作为 LLM 上下文
- LLM 不可用时自动使用离线规则回复
- 对话结果写回 NPC 个人记忆

主测试场景：`res://scenes/debug/integration_test.tscn`
