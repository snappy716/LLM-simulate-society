#!/usr/bin/env python3
"""Persistent local bridge between the existing simulation and Godot 0.2."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import threading
import urllib.request
import uuid
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
SIM_DIR = PROJECT_DIR.parent / "emergent_town_demo"
sys.path.insert(0, str(SIM_DIR))

import town_demo as sim  # noqa: E402


class SimulationBridge:
    def __init__(self) -> None:
        settings = sim.load_runtime_settings()
        output_dir = PROJECT_DIR / "data" / "simulation" / "live"
        output_dir.mkdir(parents=True, exist_ok=True)
        self.world = sim.World(sim.Config(
            seed=int(settings.get("seed", 42)), days=0,
            core_npcs=int(settings.get("core_npcs", 20)),
            simple_npcs=int(settings.get("simple_npcs", 180)),
            # Godot play-tests are offline by default. Enable an external planner only
            # through an explicit environment variable, never merely by opening the game.
            llm_mode=os.environ.get("GODOT_SIM_LLM_MODE", "rule"),
            deepseek_url=str(settings.get("deepseek_url", "https://api.deepseek.com")),
            deepseek_model=str(settings.get("deepseek_model", "deepseek-v4-flash")),
            deepseek_api_key=os.environ.get("DEEPSEEK_API_KEY") or settings.get("deepseek_api_key"),
            max_llm_core_npcs=int(settings.get("max_llm_npcs", 20)),
            llm_concurrency=int(settings.get("llm_concurrency", 5)),
            log_dir=str(output_dir), verbose=False,
        ))
        for npc in self.world.npcs.values():
            npc.daily_plan = sim.rule_plan_for_npc(self.world, npc)
        sim.arrange_social_invitations(self.world, self.world.day)
        self.revision = 1
        self.busy = False
        self.lock = threading.Lock()
        self.last_events: list[dict] = []
        self.dialogue_history: dict[str, list[dict[str, str]]] = {}
        self.snapshot_path = output_dir / "current_world.json"
        self._write_snapshot()

    def dialogue(self, npc_id: str, player_text: str) -> dict:
        npc_id = npc_id.strip()
        player_text = player_text.strip()
        if npc_id not in self.world.npcs:
            raise ValueError("NPC does not exist")
        if not player_text:
            raise ValueError("Dialogue text cannot be empty")
        if len(player_text) > 500:
            raise ValueError("Dialogue text is limited to 500 characters")
        if not self.lock.acquire(blocking=False):
            raise RuntimeError("simulation is busy")
        self.busy = True
        try:
            npc = self.world.npcs[npc_id]
            history = self.dialogue_history.setdefault(npc_id, [])
            fallback_error = ""
            try:
                reply = self._generate_dialogue_reply(npc, player_text, history)
                used_fallback = self.world.cfg.llm_mode == "rule"
            except Exception as exc:
                reply = self._rule_dialogue_reply(npc, player_text)
                used_fallback = True
                fallback_error = f"{type(exc).__name__}: {exc}"
                print(f"DIALOGUE_LLM_FALLBACK {type(exc).__name__}: {exc}", flush=True)
            history.extend([
                {"role": "player", "content": player_text},
                {"role": "npc", "content": reply},
            ])
            del history[:-16]
            event_id = f"dialogue_{self.world.day}_{npc_id}_{uuid.uuid4().hex[:8]}"
            npc.memories.append(sim.Memory(
                self.world.day, self.world.phase.value,
                f"玩家对我说：{player_text}；我回答：{reply}",
                4, event_id, ["player_dialogue", "conversation"],
            ))
            del npc.memories[:-100]
            memory_data = asdict(npc.memories[-1])
            self.revision += 1
            self._write_snapshot()
            return {
                "ok": True, "npc_id": npc_id, "npc_name": npc.name,
                "reply": reply, "fallback": used_fallback,
                "fallback_error": fallback_error,
                "memory": memory_data,
                "day": self.world.day, "phase": self.world.phase.value,
            }
        finally:
            self.busy = False
            self.lock.release()

    def _dialogue_context(self, npc, history: list[dict[str, str]]) -> dict:
        plan = npc.daily_plan.get(self.world.phase.value)
        relationship = npc.relationships.get("player")
        return {
            "day": self.world.day, "phase": self.world.phase.value,
            "name": npc.name, "occupation": npc.occupation,
            "organization": npc.organization,
            "current_scene": self._display_scene(npc),
            "health": npc.health, "sanity": npc.sanity,
            "states": npc.states, "goals": npc.goals[:5],
            "known_facts": npc.knowledge[-12:], "beliefs": npc.beliefs[-8:],
            "recent_memories": npc.relevant_memories(8),
            "current_plan": asdict(plan) if plan else {},
            "relationship_with_player": asdict(relationship) if relationship else {},
            "recent_dialogue": history[-12:],
        }

    def _generate_dialogue_reply(self, npc, player_text: str, history: list[dict[str, str]]) -> str:
        if self.world.cfg.llm_mode == "rule":
            return self._rule_dialogue_reply(npc, player_text)
        context = self._dialogue_context(npc, history)
        system_prompt = (
            "你正在扮演一个持续世界模拟游戏中的NPC。严格依据提供的人物资料、亲历记忆、知识、信念和当前计划回答。"
            "不知道的事情就明确不知道，不得读取其他NPC的秘密，不得替玩家行动，不得宣布尚未发生的世界事件。"
            "保持人物口吻，使用简体中文，回复自然简短，通常1到4句话，不要输出JSON、Markdown或系统说明。"
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": "NPC资料：" + json.dumps(context, ensure_ascii=False)},
        ]
        for item in history[-12:]:
            messages.append({
                "role": "assistant" if item.get("role") == "npc" else "user",
                "content": item.get("content", ""),
            })
        messages.append({"role": "user", "content": player_text})
        if self.world.cfg.llm_mode == "ollama":
            client = self.world.ollama
            payload = {"model": client.model, "messages": messages, "stream": False,
                       "options": {"temperature": 0.75}}
            req = urllib.request.Request(
                client.base_url + "/api/chat", data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=120) as response:
                raw = json.loads(response.read().decode("utf-8"))
            reply = str(raw.get("message", {}).get("content", "")).strip()
        else:
            client = self.world.deepseek
            payload = {"model": client.model, "messages": messages, "stream": False,
                       "thinking": {"type": "disabled"},
                       "max_tokens": 800, "temperature": 0.75}
            req = urllib.request.Request(
                client.base_url + "/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {client.api_key}"},
                method="POST")
            with urllib.request.urlopen(req, timeout=120) as response:
                raw = json.loads(response.read().decode("utf-8"))
            reply = str(raw.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
        if not reply:
            raise ValueError("LLM returned an empty dialogue reply")
        return reply[:1200]

    def _rule_dialogue_reply(self, npc, player_text: str) -> str:
        lowered = player_text.lower()
        if any(word in lowered for word in ["你好", "hello", "hi", "嗨"]):
            return f"你好。我是{npc.name}，在这里做{npc.occupation}的工作。"
        if any(word in player_text for word in ["计划", "去哪", "做什么"]):
            plan = npc.daily_plan.get(self.world.phase.value)
            if plan:
                scene = self.world.scenes.get(plan.scene_id)
                scene_name = scene.name if scene else plan.scene_id
                return f"我现在打算去{scene_name}，处理一件与‘{plan.intent}’有关的事。"
        if "记得" in player_text or "发生" in player_text:
            memories = npc.relevant_memories(1)
            if memories:
                return f"我最近一直记着这件事：{memories[0]}"
        return "我听见了。不过这件事我还需要想一想，也许之后能给你更明确的答复。"

    def configure_interface(self, config: dict) -> dict:
        provider = str(config.get("provider", "rule"))
        base_url = str(config.get("base_url", "")).strip().rstrip("/")
        model = str(config.get("model", "")).strip()
        api_key = str(config.get("api_key", "")).strip()
        if provider == "rule":
            self.world.cfg.llm_mode = "rule"
        elif provider == "ollama":
            if not base_url or not model:
                raise ValueError("Ollama requires base_url and model")
            self.world.ollama = sim.OllamaClient(base_url, model, self.world.ledger)
            self.world.cfg.llm_mode = "ollama"
        elif provider in {"deepseek", "deepseek_compatible"}:
            if not base_url or not model or not api_key:
                raise ValueError("DeepSeek-compatible API requires base_url, model, and api_key")
            self.world.deepseek = sim.DeepSeekClient(base_url, model, api_key, self.world.ledger)
            self.world.cfg.llm_mode = "deepseek"
        else:
            raise ValueError(f"unsupported provider: {provider}")
        return {
            "ok": True, "provider": provider, "base_url": base_url,
            "model": model, "api_key_configured": bool(api_key),
            "message": "接口已应用；将在下次日终规划时使用。",
        }

    def _appearance(self, npc_id: str) -> dict:
        digest = hashlib.sha256(f"{self.world.cfg.seed}:{npc_id}".encode()).digest()
        seed = int.from_bytes(digest[:4], "big") & 0x7FFFFFFF
        return {"body_type": "male" if digest[4] % 2 == 0 else "female", "seed": seed}

    def _display_scene(self, npc) -> str:
        plan = npc.daily_plan.get(self.world.phase.value)
        return plan.scene_id if plan and plan.scene_id in self.world.scenes else npc.current_scene

    def snapshot(self) -> dict:
        public_scenes = {
            sid: asdict(scene) for sid, scene in self.world.scenes.items()
            if "private_home" not in scene.tags
        }
        npcs = {}
        for npc_id, npc in self.world.npcs.items():
            meaningful_relations = {
                target_id: asdict(relation)
                for target_id, relation in npc.relationships.items()
                if relation.kinds or relation.trust != 50 or relation.affection != 0
                or relation.suspicion != 0 or relation.fear != 0
            }
            npcs[npc_id] = {
                "id": npc.id, "name": npc.name, "tier": npc.tier,
                "occupation": npc.occupation, "organization": npc.organization,
                "layer": npc.layer, "sequence_pathway": npc.sequence_pathway,
                "sequence_rank": npc.sequence_rank, "faction_ids": npc.faction_ids,
                "current_scene": npc.current_scene, "display_scene": self._display_scene(npc),
                "home_scene": npc.home_scene, "work_scene": npc.work_scene,
                "health": npc.health, "sanity": npc.sanity, "wealth": npc.wealth,
                "alive": npc.alive, "disposition_status": npc.disposition_status,
                "states": npc.states, "special_needs": npc.special_needs,
                "goals": npc.goals, "dominant_desires": [
                    asdict(item) for item in self.world.desire_engine.dominant(npc, self.world)
                ],
                "memories": [asdict(memory) for memory in npc.memories[-20:]],
                "daily_plan": {key: asdict(value) for key, value in npc.daily_plan.items()},
                "relationships": meaningful_relations,
                "long_term_goal_ids": npc.long_term_goal_ids,
                "appearance": self._appearance(npc_id),
            }
        return {
            "schema_version": 1, "revision": self.revision,
            "day": self.world.day, "weekday": (self.world.day - 1) % 7,
            "phase": self.world.phase.value, "busy": self.busy,
            "player_scene": self.world.player_scene,
            "scenes": public_scenes, "npcs": npcs,
            "new_events": self.last_events[-50:],
        }

    def _write_snapshot(self) -> dict:
        data = self.snapshot()
        temporary = self.snapshot_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.snapshot_path)
        return data

    def step(self) -> dict:
        if not self.lock.acquire(blocking=False):
            raise RuntimeError("simulation is already advancing")
        self.busy = True
        try:
            day = self.world.day
            before = len(self.world.events_by_day[day])
            current_phase = self.world.phase
            if current_phase == sim.Phase.MORNING:
                sim.inject_demo_player_commitment(self.world)
            sim.simulate_phase(self.world, current_phase)
            if current_phase == sim.Phase.LATE_NIGHT:
                sim.resolve_end_of_day(self.world)
                night_start = len(self.world.events_by_day[day])
                sim.run_night_fate_events(self.world)
                night_events = self.world.events_by_day[day][night_start:]
                if night_events:
                    sim.write_memories_from_events(self.world, night_events)
                    sim.update_beliefs_from_events(self.world, night_events)
                    sim.update_story_threads_from_events(self.world, night_events)
                    sim.generate_harm_and_report_reactions(self.world, night_events)
                sim.generate_incident_response_drives(self.world, self.world.events_by_day[day])
                sim.sync_long_term_goals(self.world)
                sim.plan_tomorrow(self.world)
                self.world.day += 1
                self.world.phase = sim.Phase.MORNING
            else:
                index = sim.PHASES.index(current_phase)
                self.world.phase = sim.PHASES[index + 1]
            produced = self.world.events_by_day[day][before:]
            self.last_events = [{
                "event_id": event.event_id, "day": event.day, "phase": event.phase,
                "event_type": event.event_type, "scene_id": event.scene_id,
                "actor_ids": event.actor_ids, "message": event.description,
                "tags": event.tags, "level": event.level,
            } for event in produced]
            self.revision += 1
            return self._write_snapshot()
        finally:
            self.busy = False
            self.lock.release()


class Handler(BaseHTTPRequestHandler):
    bridge: SimulationBridge

    def _reply(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path in ("/health", "/snapshot"):
            payload = {"ok": True} if self.path == "/health" else self.bridge.snapshot()
            self._reply(200, payload)
        else:
            self._reply(404, {"error": "not found"})

    def do_POST(self) -> None:
        if self.path not in {"/step", "/configure", "/dialogue"}:
            self._reply(404, {"error": "not found"})
            return
        try:
            if self.path == "/step":
                self._reply(200, self.bridge.step())
            elif self.path == "/configure":
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
                self._reply(200, self.bridge.configure_interface(payload))
            else:
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
                self._reply(200, self.bridge.dialogue(
                    str(payload.get("npc_id", "")), str(payload.get("text", ""))))
        except Exception as exc:
            self._reply(500, {"error": f"{type(exc).__name__}: {exc}"})

    def log_message(self, _format: str, *_args) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    Handler.bridge = SimulationBridge()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"GODOT_SIMULATION_READY http://127.0.0.1:{args.port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
