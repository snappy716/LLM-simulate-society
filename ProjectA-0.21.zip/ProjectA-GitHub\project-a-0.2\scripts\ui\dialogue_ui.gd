extends CanvasLayer

@export var interaction_distance := 96.0

@onready var prompt: Label = $InteractPrompt
@onready var panel: Panel = $DialoguePanel
@onready var title: Label = $DialoguePanel/Title
@onready var history_label: RichTextLabel = $DialoguePanel/History
@onready var input: LineEdit = $DialoguePanel/Input
@onready var send_button: Button = $DialoguePanel/Send
@onready var close_button: Button = $DialoguePanel/Close
@onready var status: Label = $DialoguePanel/Status

var dialogue_open := false
var _nearest_npc: Node2D
var _active_npc: Node2D
var _waiting := false
var _scan_elapsed := 0.0


func _ready() -> void:
	add_to_group("dialogue_ui")
	panel.hide()
	prompt.hide()
	input.text_submitted.connect(_on_text_submitted)
	send_button.pressed.connect(_send_current_text)
	close_button.pressed.connect(close_dialogue)
	SimulationBridge.dialogue_completed.connect(_on_dialogue_completed)


func _process(delta: float) -> void:
	if dialogue_open:
		if not is_instance_valid(_active_npc):
			close_dialogue()
		return
	_scan_elapsed += delta
	if _scan_elapsed < 0.12:
		return
	_scan_elapsed = 0.0
	_nearest_npc = _find_nearest_npc()
	if _nearest_npc == null:
		prompt.hide()
	else:
		var npc_name := _npc_display_name(_nearest_npc)
		prompt.text = "按 F 与 %s 对话" % npc_name
		prompt.show()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact") and not dialogue_open and _nearest_npc != null:
		open_dialogue(_nearest_npc)
		get_viewport().set_input_as_handled()


func open_dialogue(npc: Node2D) -> void:
	if not is_instance_valid(npc):
		return
	_active_npc = npc
	dialogue_open = true
	prompt.hide()
	panel.show()
	title.text = "与 %s 对话" % _npc_display_name(npc)
	history_label.text = "你走近了 %s。\n\n" % _npc_display_name(npc)
	status.text = "输入文字后按 Enter 或点击发送"
	input.editable = true
	send_button.disabled = false
	input.clear()
	input.grab_focus()


func close_dialogue() -> void:
	if _waiting:
		status.text = "正在等待回复，暂时无法关闭"
		return
	dialogue_open = false
	_active_npc = null
	panel.hide()
	input.release_focus()


func _on_text_submitted(_text: String) -> void:
	_send_current_text()


func _send_current_text() -> void:
	if _waiting or not dialogue_open or not is_instance_valid(_active_npc):
		return
	var text := input.text.strip_edges()
	if text.is_empty():
		status.text = "请输入对话内容"
		return
	if text.length() > 500:
		status.text = "单次输入不能超过 500 个字符"
		return
	_waiting = true
	input.editable = false
	send_button.disabled = true
	status.text = "对方正在思考……"
	history_label.text += "你：%s\n\n" % text
	history_label.scroll_to_line(history_label.get_line_count())
	input.clear()
	SimulationBridge.send_dialogue(String(_active_npc.npc_id), text)


func _on_dialogue_completed(success: bool, result: Dictionary) -> void:
	_waiting = false
	input.editable = true
	send_button.disabled = false
	if success:
		var speaker := String(result.get("npc_name", _npc_display_name(_active_npc)))
		history_label.text += "%s：%s\n\n" % [speaker, result.get("reply", "……")]
		if bool(result.get("fallback", false)):
			var fallback_error := String(result.get("fallback_error", ""))
			status.text = "离线规则回复" if fallback_error.is_empty() else "LLM 失败，已回退：%s" % fallback_error
		else:
			status.text = "DeepSeek / LLM 回复成功"
	else:
		history_label.text += "[对话请求失败：%s]\n\n" % result.get("error", "未知错误")
		status.text = "发送失败，可以重试"
	history_label.scroll_to_line(history_label.get_line_count())
	input.grab_focus()


func _find_nearest_npc() -> Node2D:
	var player := get_tree().get_first_node_in_group("player") as Node2D
	if player == null:
		return null
	var closest: Node2D
	var closest_distance := interaction_distance
	for candidate in get_tree().get_nodes_in_group("simulated_npc"):
		var npc := candidate as Node2D
		if npc == null or not is_instance_valid(npc):
			continue
		var distance := player.global_position.distance_to(npc.global_position)
		if distance <= closest_distance:
			closest = npc
			closest_distance = distance
	return closest


func _npc_display_name(npc: Node) -> String:
	if npc == null:
		return "NPC"
	var data: Dictionary = npc.get_meta("simulation_data", {})
	return String(data.get("name", npc.npc_id))
