
# Emergent Town Demo

## 项目文档

- [系统设定一览](docs/GAME_SYSTEM_REFERENCE.md)：面向策划和展示，集中说明状态、职业、场景、阵营、行为、欲望、情报与长期计划。
- [200 人职业排班表](docs/NPC_ROSTER.csv)：可用 Excel 打开，包含职业、隶属地点、工作日、班次和非凡身份。
- [初始关系网](docs/NPC_RELATIONSHIPS.csv)：双向关系边，包含朋友、仇人、同事、前同事和爱人。

## 无参数运行

默认运行设置保存在 `config.json`，本地 DeepSeek 密钥保存在被 Git 忽略的 `config.local.json`。因此可以从任意目录直接运行：

```powershell
python "C:\游戏\ProjectA\emergent_town_demo\town_demo.py"
```

默认配置为 200 名 NPC、运行 7 天、仅非凡者调用 DeepSeek、最多 20 名 LLM NPC、并发数 5，输出到项目内的 `runs/latest`。命令行参数仍可临时覆盖配置，例如 `--days 1 --llm rule`。
- [冒烟测试记录](docs/SMOKE_TEST.txt)

## 目录结构

```text
emergent_town_demo/
├─ town_demo.py              # 兼容入口与当前主模拟器
├─ emergent_town/            # 可复用领域模块
│  ├─ actions/               # 行为定义、注册与目录
│  └─ plots/                 # 长期计划和后果链
├─ tests/                    # 自动化测试
├─ docs/                     # 面向开发和策划的文档
└─ runs/                     # 当前与历史运行结果
   └─ archive/               # 从旧根目录归档的历史结果
```

运行测试：

```powershell
python -m unittest discover -s tests -v
```

## 运行

先测试规则模式：

```bash
python town_demo.py --days 3 --llm rule
```

接 Ollama：

```bash
ollama serve
ollama list
python town_demo.py --days 3 --llm ollama --model qwen3:8b
```

如果你的模型不是 `qwen3:8b`，把 `--model` 改成 `ollama list` 显示的实际名称。

## 核心循环

```text
Morning
Afternoon
Evening
Late Night
↓
所有场景都模拟完成
↓
Night Resolution
  - 写 Memory
  - 更新 Belief
  - 更新 StoryThread
  - 生成 Commission
↓
Night Fate Events
↓
把夜间事件也写入 Memory / StoryThread
↓
生成次日 ResponseDrive
  - 值夜者封锁与调查
  - 敌对非凡者掩盖或反侦察
  - 野生非凡者谨慎探查
↓
Planning Barrier
↓
最后才调用 Ollama/Qwen 规划明天
```

## 模块化剧情发动机

新系统位于 `emergent_town/`：

```text
emergent_town/
├── models.py                 # 欲望、情报、痕迹、组织行动计划
├── desires.py                # 状态→竞争欲望
├── intelligence.py           # 结构化情报、保密与传播
├── actions/
│   ├── registry.py            # 行为注册、前置条件和执行结果
│   └── catalog.py             # 生存、经济、社交、犯罪、调查和官方行为
└── plots/
    └── illegal_ritual.py      # 非法仪式多阶段行动模块
```

当前非法仪式链条：

```text
选择目标 → 收集材料 → 准备场地 → 举行仪式 → 清理/撤离
                         ↓
                      留下痕迹
                         ↓
          实际搜查→结构化情报→案件升级
                         ↓
                 监视→干预计划→阻止检定
```

快照会保存 `intelligence`、`trace_evidence`、`operations`、案件阶段和 NPC 的主导欲望。

## 白天模拟

1. NPC 根据前一晚计划决定当前时段 Scene。
2. 按 Scene 聚合 NPC。
3. 玩家所在场景记为 `VISIBLE_SCENE_SIM`。
4. 其他场景记为 `OFFSCREEN_SCENE_SIM`。
5. 只有同场景 NPC 才会计算 Interaction Score。
6. 高分互动才真正发生。
7. 所有结果写入 Event Ledger。

## 默认规模

- 20 Core NPC
- 60 Simple NPC
- 12 Scenes

可改：

```bash
python town_demo.py --core 30 --simple 120 --days 5 --llm rule
```

## 日志

```text
logs/
├── trace.jsonl
├── world_history.log
├── snapshot_day_001.json
├── npc_history/
├── story_threads/
└── llm/
```

`trace.jsonl` 是最完整的机器可追溯日志。

`world_history.log` 适合直接阅读。

`npc_history/npc_XXX.log` 可以查看一个 NPC 一路经历了什么。

`story_threads/thread_XXX.log` 可以看一条涌现剧情线如何长出来。

`llm/*_request.json` 和 `*_response.json` 保存每次 Ollama 的原始输入输出。

## DeepSeek 规划后端

DeepSeek 密钥只从环境变量读取，不会写进源码或请求日志。PowerShell 示例：

```powershell
$env:DEEPSEEK_API_KEY = "你的新密钥"
python town_demo.py --days 3 --llm deepseek --deepseek-model deepseek-v4-flash
```

可调整每晚规划人数和并发数：

```powershell
python town_demo.py --days 10 --llm deepseek --max-llm-npcs 8 --llm-concurrency 5
```

可选参数：

```text
--deepseek-url https://api.deepseek.com
--deepseek-model deepseek-v4-flash
```

DeepSeek 请求失败、返回空内容或计划未通过本地校验时，NPC 会自动使用规则规划。建议为每次测试指定独立的 `--log-dir`。

DeepSeek 默认使用 Flash 非思考模式，每晚只选择最重要的 8 名 NPC，最多 5 路并发，单次输出限制为 800 tokens。

## Day 2 的玩家影响示例

Demo 内置：

```text
Day 2 Morning
玩家告诉 Robert：
“下午来黑夜女神教堂。”
```

系统不会重新调用 LLM，而是创建 `Commitment`。

到 Afternoon 时，该承诺与原计划比较优先级，Robert 才改变场景。

## 当前 Demo 已实现

- 4 时段
- 多场景
- Core / Simple NPC
- 每个时段所有场景后台模拟
- 同场景互动
- 关系
- 知识传播
- 调查
- 隐藏证据
- 秘密活动
- 条件场景事件
- 预设事件
- 夜间命运事件
- Memory
- Belief
- StoryThread
- Commission
- Ollama/Qwen 每日晚间规划
- LLM 输出合法化
- LLM 失败自动规则 fallback
- 完整 trace
- 廷根世界主矛盾：官方非凡秩序与邪恶组织、失控者的长期对抗
- NPC 分层：普通人、官方非凡者、野生非凡者、敌对非凡者
- 途径、序列、阵营、职责与 ResponseDrive
- 夜间突发事件强制影响次日白天行为，不会被 LLM 日常计划覆盖
- 廷根非凡者限定为序列 9、8、7，序列数字越小则相关领域检定加值越高
- 追踪与反侦察使用可审计的 d100 对抗检定，完整骰点和修正写入 `trace.jsonl`
- 黑夜女神教堂是官方控制的非凡防护圣所，不会触发普通场景的随机灵异事件
