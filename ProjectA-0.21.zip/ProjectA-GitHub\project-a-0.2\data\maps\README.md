# Editable Tinggen map

`tinggen_city_layout.png` is the editable 400 x 400 source of truth. One pixel equals one tile.

- `#244957`: water (blocked)
- `#344f3d`: land (blocked)
- `#aaa49b`: road/plaza (walkable)
- `#765548`: building footprint (blocked)
- `#4f7548`: garden (blocked)

For small edits, add cells to `tinggen_city_overrides.json`, for example:

```json
{"x": 139, "y": 190, "type": "road"}
```

Runtime loading never regenerates or overwrites these files.

## Temporary ground terrain

The logical layout drives two synchronized TileMapLayer nodes:

- `TemporaryGroundTerrain`: visible temporary grass, stone road, water, building foundation and garden tiles.
- `TinggenCityTiles_400x400`: hidden logic tiles that provide collision and navigation.

The in-game correction tool updates both layers immediately. Saving writes the authoritative
400 x 400 layout PNG, so terrain changes remain after restarting the project.

Buildings are intended to remain exterior-only. A building entrance will be an interaction
anchor that opens or transfers to a location, without rendering a walkable interior.
